-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 24 Okt 2024 pada 04.07
-- Versi server: 10.4.32-MariaDB
-- Versi PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `portofolio`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `about_section`
--

CREATE TABLE `about_section` (
  `id` int(11) NOT NULL,
  `title` varchar(50) NOT NULL,
  `description` text NOT NULL,
  `instagram_link` varchar(50) NOT NULL,
  `linkedin_link` varchar(50) NOT NULL,
  `github_link` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `about_section`
--

INSERT INTO `about_section` (`id`, `title`, `description`, `instagram_link`, `linkedin_link`, `github_link`) VALUES
(1, 'About Me', 'Hi, I’m Shevila Damayanti, a web designer and front-end developer with a passion for creating stunning, user-friendly websites. With over 1 years of experience in the industry, I’ve developed a deep understanding of both design principles and coding techniques. I specialize in HTML, CSS, JavaScript, and I love building clean, responsive websites that work across all devices.\r\n                                    I thrive on the creative process and enjoy bringing ideas to life through intuitive user interfaces. Constantly learning and adapting to new technologies, I’m always on the lookout for exciting challenges that push me to grow', 'https://www.instagram.com/svylaa/profilecard/?igsh', 'linkedin.com/in/sheviladamayanti', 'https://github.com/sevill32');

-- --------------------------------------------------------

--
-- Struktur dari tabel `contact`
--

CREATE TABLE `contact` (
  `no` int(11) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `handphone` varchar(50) NOT NULL,
  `pesan` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `contact`
--

INSERT INTO `contact` (`no`, `nama`, `email`, `handphone`, `pesan`) VALUES
(1, 'mira santika', 'miracantik@gmail.com', '08123456789', 'hai'),
(2, 'mira santika', 'miracantik@gmail.com', '08123456789', 'hai'),
(3, 'mira santika', 'miracantik@gmail.com', '08123456789', 'hai'),
(4, 'mira santika', 'miracantik@gmail.com', '08123456789', 'hai'),
(5, 'mira santika', 'miracantik@gmail.com', '08123456789', 'hai'),
(6, 'mira santika', 'miracantik@gmail.com', '08123456789', 'hai'),
(7, 'Shevila Damayanti', 'shevilladamayanti1@gmail.com', '085664538168', 'hallo'),
(8, 'Shevila Damayanti', 'shevilladamayanti1@gmail.com', '085664538168', 'hallo'),
(9, 'Shevila Damayanti', 'shevilladamayanti1@gmail.com', '085664538168', 'hallo');

-- --------------------------------------------------------

--
-- Struktur dari tabel `education`
--

CREATE TABLE `education` (
  `id` int(11) NOT NULL,
  `institution` varchar(50) NOT NULL,
  `degree` varchar(50) NOT NULL,
  `field_of_study` varchar(50) NOT NULL,
  `duration` varchar(50) NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `education`
--

INSERT INTO `education` (`id`, `institution`, `degree`, `field_of_study`, `duration`, `description`) VALUES
(1, 'Pembangunan Jaya University', 'Undergraduate', 'Informatics Engineering', '2023 - Present', 'Studied core subjects such as Human-computer interaction, web development, database management, and algorithms.\r\n\r\nActive member of the Informatics Learning Together (FORKABES) IOT club.\r\n\r\nWorking on mobile app UI/UX design project in human and computer interaction course.'),
(2, 'Al Madinah Islamic Center KKMB High School', '', 'IPA', '2020 - 2023', 'Focused on math and computer science, which sparked my interest to pursue a career in Information Technology.\r\n\r\nGraduated with honors, actively participated in organizational activities such as student council.\r\n\r\nLed a school project in making electrical circuits.');

-- --------------------------------------------------------

--
-- Struktur dari tabel `experience`
--

CREATE TABLE `experience` (
  `id` int(11) NOT NULL,
  `job_title` varchar(50) NOT NULL,
  `company` varchar(50) NOT NULL,
  `duration` varchar(50) NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `experience`
--

INSERT INTO `experience` (`id`, `job_title`, `company`, `duration`, `description`) VALUES
(1, 'Web Developer', 'Pembangunan Jaya University', '2024 - Present', 'Create a simple website using HTML, CSS, and Bootstrap\r\nIn addition, create a database using MYSQL and then connected with PHP\r\nLearn to create forms with GET and POST methods on the simple web'),
(2, 'Content Writer - Jaya Stock Club', 'Pembangunan Jaya University', '2024 - Present', 'Creating engaging and informative content on investment strategies, stock market trends, and financial literacy for a wide audience.\r\nWrite content on social media posts relating to stock market analysis, investment tips, and market updates.\r\nSimplify complex financial concepts into language that is easily understood by novice investors'),
(3, 'Creative Designer', 'Rumah Sandar', 'Aug - Nov 2024', 'Develop new concepts and ideas that are unique and innovative in design.\r\n\r\nCommunicate with the copywriter team regarding the design of Instagram feeds and stories.\r\n\r\nCreate visual designs using design elements such as color, typography, image, composition, and other visual elements.'),
(4, 'UI/UX Designer', 'Pembangunan Jaya University', '2023', 'Design and develop an easy-to-use scheduling application that allows users to organize their daily tasks efficiently.\r\n\r\nConduct user research to understand user needs and preferences related to task scheduling and time management.\r\n\r\nCreate wireframes and prototypes using tools such as Figma to visualize the interface and flow.');

-- --------------------------------------------------------

--
-- Struktur dari tabel `projects`
--

CREATE TABLE `projects` (
  `id` int(11) NOT NULL,
  `title` varchar(50) NOT NULL,
  `description` text NOT NULL,
  `image` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `projects`
--

INSERT INTO `projects` (`id`, `title`, `description`, `image`) VALUES
(1, 'Web Article', 'This project features a simple website built using HTML and Bootstrap, designed with a responsive and user-friendly structure. It includes key elements such as a navbar for easy navigation, attractive illustrated articles, and an informative footer', 'assets/web1.png'),
(2, 'Investment', 'Help increase audience engagement by delivering well-researched content that provides actionable insights on investing. Contribute to a growing community of investors, offering practical knowledge that supports better financial decision-making', 'assets/saham.png'),
(3, 'Database', 'In this project, I learned and implemented various basic and advanced concepts in database management. Using MySQL and PHP, I designed an efficient database to store, manage, and display data dynamically on a website. The project involved creating tables, designing relationships between data, and applying SQL queries for data manipulation', 'assets/database.png'),
(4, 'Carousel Content', 'This carousel is designed to display a series of images, text, and other multimedia elements with easy and responsive navigation. Each slide focuses on a specific topic, allowing users to quickly explore a wide range of information and capture attention', 'assets/sosmed.png'),
(5, 'AResto', 'The app is designed to optimize restaurant operations across the board, focusing on the ordering, payment, and inventory management processes. With advanced features that utilize real-time technology. With this app, restaurants can improve operational efficiency, reduce errors, and provide faster and more satisfying service to customers', 'assets/AResto.png'),
(6, 'TB Shield', 'A health management application that focuses on tuberculosis (TB) disease management and prevention with a variety of modern features. Helps users manage TB routinely with structured guidance, informs the condition of an area including infected areas for better prevention efforts, and makes it easier for users to recognize TB symptoms for faster treatment', 'assets/TuberShield (1).png');

-- --------------------------------------------------------

--
-- Struktur dari tabel `skills`
--

CREATE TABLE `skills` (
  `id` int(11) NOT NULL,
  `category` varchar(50) NOT NULL,
  `skill` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `skills`
--

INSERT INTO `skills` (`id`, `category`, `skill`) VALUES
(1, 'Professional Skills', 'Desain Interaksi'),
(2, 'Professional Skills', 'Wireframing'),
(3, 'Professional Skills', 'Prototyping'),
(4, 'Professional Skills', 'HTML5'),
(5, 'Professional Skills', 'CSS3'),
(6, 'Professional Skills', 'Editing & Proofreading'),
(7, 'Software Skills', 'Figma'),
(8, 'Software Skills', 'Canva'),
(9, 'Software Skills', 'Visual Studio Code'),
(10, 'Software Skills', 'Google Docs'),
(11, 'Software Skills', 'Google Sheets'),
(12, 'Software Skills', 'Microsoft Office');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `about_section`
--
ALTER TABLE `about_section`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`no`);

--
-- Indeks untuk tabel `education`
--
ALTER TABLE `education`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `experience`
--
ALTER TABLE `experience`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `projects`
--
ALTER TABLE `projects`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `skills`
--
ALTER TABLE `skills`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `contact`
--
ALTER TABLE `contact`
  MODIFY `no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
