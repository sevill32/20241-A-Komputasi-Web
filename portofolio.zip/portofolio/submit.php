<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="web portofolio" />
        <meta name="author" content="vila" />
        <title>Web Portofolio Shevila </title>
        <!-- Favicon-->
        <link rel="icon" type="image/x-icon" href="assets/favicon porto.png" />
        <!-- Custom Google font-->
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
        <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@100;200;300;400;500;600;700;800;900&amp;display=swap" rel="stylesheet" />
        <!-- Bootstrap icons-->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css" rel="stylesheet" />
        <!-- Core theme CSS (includes Bootstrap)-->
        <link href="css/styles.css" rel="stylesheet" />
    </head>
<?php
include('koneksi.php');

$nama = $_POST['nama'];
$email = $_POST['email'];
$handphone = $_POST['nomer_telpon'];
$pesan = $_POST['pesan'];

// Masukkan data ke dalam tabel tanpa memasukkan primary key
$submit = mysqli_query($koneksi, "INSERT INTO contact (nama, email, handphone, pesan) VALUES ('$nama', '$email', '$handphone', '$pesan')");

if ($submit) {
    echo "Berhasil tersimpan ke database 😊";
} else {
    echo "Gagal tersimpan ke database 😞: " . mysqli_error($koneksi);
}

?>
<!DOCTYPE html>
<html lang="en">
    <br></br>
<!-- Call to action section-->
<section class="py-5 bg-gradient-primary-to-secondary text-white">
    <div class="container px-5 my-5">
        <div class="text-center">
        <h3 class="display-6 fw-bolder mb-6">Thank you for visiting my portfolio website!</h3>
            <!-- Tombol Back ke Home -->
            <a class="btn btn-light btn-lg px-5 py-3 fs-6 fw-bolder mt-3" href="index.php">Back to Home</a>
        </div>
    </div>
</section>
<!-- Bootstrap core JS-->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
<!-- Core theme JS-->
<script src="js/scripts.js"></script>