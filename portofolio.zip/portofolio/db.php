<?php
$server = "localhost";
$user = "root";
$password = "";
$database = "portofolio";

// Menghubungkan ke database menggunakan PDO
try {
    $pdo = new PDO("mysql:host=$server;dbname=$database", $user, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}
?>