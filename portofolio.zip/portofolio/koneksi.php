<?php

$server ="localhost";
$user ="root";
$password = "";
$database = "portofolio";

$koneksi = mysqli_connect($server,$user,$password,$database);

if($koneksi == TRUE) {
    // echo "Berhasil terhubung ke database";
}
else {
    echo "Gagal terhubung ke database";
}

 
?>
